#coding:utf8

'''
setup proxy:
adb shell settings put global http_proxy <ip>:<port>

remove proxy:
adb shell settings delete global http_proxy
adb shell settings delete global global_http_proxy_host
adb shell settings delete global global_http_proxy_port
reboot


//openssl x509 -inform DER -in cacert.der -out cacert.pem  
//openssl x509 -inform PEM -subject_hash_old -in cacert.pem |head -1  
//mv cacert.pem <hash>.0

//adb disable-verity 复制到system也可以

//或umount /system/etc/security/cacerts;cp -pR /system/etc/security/cacerts /data/local/tmp/;cp /data/local/tmp/269953fb.0 /data/local/tmp/cacerts/;chmod -R 755 /data/local/tmp/cacerts;chcon -R `ls -Z /system/etc/security/cacerts | head -n1 | cut -d " " -f 1 ` /data/local/tmp/cacerts;mount /data/local/tmp/cacerts /system/etc/security/cacerts;

'''
import argparse, sys, os
import subprocess


def execShellDaemon(cmd):
    '''
    功能：后台运行shell命令，不阻塞
    参数：shell命令
    返回：Popen对象
    '''
    return subprocess.Popen(cmd, shell=True, stderr=subprocess.PIPE, stdout=subprocess.PIPE)

def execShell(cmd, t=120):
    '''
    功能：前台运行shell命令，阻塞
    参数：shell命令
    返回：成功返回{'d': DATA}，失败返回{'e': DATA}
    #不同手机执行成功/失败返回值不一致，可使用'ssss' in str(ret)方式判断
    '''
    ret = {}
    try:
        p = subprocess.run(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE, shell=True, encoding='utf-8', timeout=t)
        if p.returncode == 0:
            ret['d'] = p.stdout
        else:
            ret['e'] = p.stderr
    except subprocess.TimeoutExpired:
        ret['e'] = 'timeout'

    return ret

def importCert(cert):
    if os.path.isfile(cert):
        out = execShell('adb push '+cert+' /data/local/tmp/')
        if '1 file pushed' not in str(out):
            print('cert push error '+str(out))
    else:
        print('cert file error: '+cert)
        return

    certname = os.path.basename(cert)
    print('Use cert '+certname)

    #不同shell返回不一样
    out = execShell('adb shell "ls -Z /system/etc/security/cacerts | head -n1"')
    con = out.get('d')
    if con:
        conc = con.split(' ')
        for c in conc:
            if 'u:' in c:
                con = c
        #print(con)
    if not con:
        print('con error')
        print(out)
        return

    #adb shell是否默认root权限
    if '(root)' not in str(execShell('adb shell id')):
        out = ""
        out += str(execShell("adb shell su -c 'setenforce 0 '"))
        #print("adb no default root, may not work well')
        out += str(execShell("adb shell su -c 'umount /system/etc/security/cacerts'"))
        out += str(execShell("adb shell su -c 'cp -pR /system/etc/security/cacerts /data/local/tmp/'"))
        out += str(execShell("adb shell su -c 'cp /data/local/tmp/"+certname+" /data/local/tmp/cacerts/'"))
        out += str(execShell("adb shell su -c 'chmod -R 755 /data/local/tmp/cacerts'"))
        out += str(execShell("adb shell su -c 'chcon -R "+con+" /data/local/tmp/cacerts'"))
        out += str(execShell("adb shell su -c 'mount /data/local/tmp/cacerts /system/etc/security/cacerts'"))
    else:
        #子命令使用单引号，否则在红米shell可能出问题
        out = ""
        out += str(execShell("adb shell 'umount /system/etc/security/cacerts'"))
        out += str(execShell("adb shell 'cp -pR /system/etc/security/cacerts /data/local/tmp/'"))
        out += str(execShell("adb shell 'cp /data/local/tmp/"+certname+" /data/local/tmp/cacerts/'"))
        out += str(execShell("adb shell 'chmod -R 755 /data/local/tmp/cacerts'"))
        out += str(execShell("adb shell 'chcon -R "+con+" /data/local/tmp/cacerts'"))
        out += str(execShell("adb shell 'mount /data/local/tmp/cacerts /system/etc/security/cacerts'"))

    out1 = execShell('adb shell mount')
    if "/system/etc/security/cacerts" not in str(out1):
        #print('cert '+out)
        out += str(execShell("adb shell umount /system/etc/security/cacerts"))
        out += str(execShell("adb shell cp -pR /system/etc/security/cacerts /data/local/tmp/"))
        out += str(execShell("adb shell cp /data/local/tmp/"+certname+" /data/local/tmp/cacerts/"))
        out += str(execShell("adb shell chmod -R 755 /data/local/tmp/cacerts"))
        out += str(execShell("adb shell chcon -R "+con+" /data/local/tmp/cacerts"))
        out += str(execShell("adb shell mount /data/local/tmp/cacerts /system/etc/security/cacerts"))

        out1 = execShell('adb shell mount')
        if "/system/etc/security/cacerts" not in str(out1):
            print('cert '+out)
        else:
            print('证书导入成功')
    else:
        print('证书导入成功')

def setProxy(ipport):
    out = execShell('adb shell settings put global http_proxy '+ipport)
    if "{'d': ''}" != str(out):
        print('proxy '+str(out))
    else:
        print('代理设置成功')

def unsetProxy():
    execShell('adb shell settings delete global http_proxy')
    execShell('adb shell settings delete global global_http_proxy_host')
    out = execShell('adb shell settings delete global global_http_proxy_port')
    if 'Deleted ' in str(out):
        print('Unset proxy done, reboot phone manually')
        #execShell('adb reboot')
    else:
        print('del proxy error')
        print(out)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='证书导入&代理设置', formatter_class=argparse.RawDescriptionHelpFormatter,
    epilog='''使用示例：
    python3 mitmSetup.py 默认导入mitmscan证书，不设置代理
    python3 mitmSetup.py -c c8750f0d.0  导入其他证书
    python3 mitmSetup.py -p 1.1.1.1:8888  设置代理
    python3 mitmSetup.py -c c8750f0d.0 -p 1.1.1.1:8888 
    python3 mitmSetup.py -P   删除代理配置

    证书名转hash.0格式方法：
    openssl x509 -inform DER -in your_cacert.der -out cacert.pem  
    openssl x509 -inform PEM -subject_hash_old -in cacert.pem |head -1
    mv cacert.pem <hash>.0
    ''')

    parser.add_argument("-c", "--cert", type=str, help="证书文件名如: c8750f0d.0")
    parser.add_argument("-p", "--proxy", type=str, help="ip:port 设置代理（或通过WiFi手动设置代理）")
    parser.add_argument("-P", "--delProxy", action="store_true", help="删除代理并重启手机")

    if sys.version_info.major != 3:
        print('Run with python3')
        sys.exit()
    print('Use -h to see help')

    #检测adb程序是否存在，并检测是否连接手机
    device = execShell('adb devices -l')
    if 'device ' not in str(device):
        print('adb or device error')
        print(device)
        sys.exit()

    args = parser.parse_args()
    cert = args.cert
    proxy = args.proxy
    delProxy = args.delProxy

    if delProxy:
        unsetProxy()
        sys.exit()

    if not cert:
        #mitm
        cert = 'c8750f0d.0'
    importCert(cert)

    if proxy:
        #proxy = '10.38.15.154:80'
        setProxy(proxy)
